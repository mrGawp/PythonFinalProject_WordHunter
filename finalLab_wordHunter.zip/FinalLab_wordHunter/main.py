import pygame
import sys
import random
import time

# Constants
WIDTH, HEIGHT = 800, 600
FPS = 60
WHITE = (255, 255, 255)
RED = (255, 0, 0)
FONT_SIZE = 36
BIG_FONT_SIZE = 69
SMALL_FONT_SIZE = 20
MAX_WORD_WIDTH = 200  # Adjust as needed

# Initialize Pygame
pygame.init()

# Create a window
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Word Hunter")
clock = pygame.time.Clock()

# Load font
font = pygame.font.Font(None, FONT_SIZE)
big_font = pygame.font.Font(None, BIG_FONT_SIZE)
small_font = pygame.font.Font(None, SMALL_FONT_SIZE)

# Load background image
background_image = pygame.image.load("stage.png")
background_image = pygame.transform.scale(background_image, (WIDTH, HEIGHT))

# Button variables
button_color = (50, 50, 50)
button_hover_color = (70, 70, 70)

# Game state variables
words = []
word_speed = 1
score = 0
typed_letters = ""
last_spawn_time = pygame.time.get_ticks()
game_over = False
in_home_screen = True
current_level = 1
word_delay = 3000
image_display_time = 100  # in milliseconds
image_display_start_time = 0
image_display_rect = pygame.Rect(0, 0, 100, 100)  # Adjust the rect size as needed
image_surface = pygame.image.load("explosion.png")  # Replace with your image file
image_surface = pygame.transform.scale(image_surface, image_display_rect.size)
level_delay_countdown = 0
string_shortWords = "cat dog sun kite fish tree bear moon jump rock lamp frog duck play fire book hand blue flag wind star road ball rain note lake card ship gold rose grin sand pine roar gift pink tide seed swim wolf leaf snow bell door song yarn mint apple table chair train earth sleep laugh river olive blend peace radio grime jumbo maple shout chest flint dance pilot"
string_LongWords = "guitarist elephant marathon cherish rainbow triangle vacation password building kindness laughter computer daughter discovery celebrate mountain language butterfly adventure happiness tomorrow pineapple universe knowledge paradise waterfall beautiful firefly melody wonderful architect cathedral sunshine journey galaxy"
string_LongerWords = "exemplifying spectacular jubilantness extraordinary melodiousness invigorating inquisitively unpredictably revolutionary constellation discombobulate insurmountable unapologetic magnification inefficiency conversation kaleidoscopic understanding determination tranquility supercalifragilisticexpialidocious serendipitous differentiation fortuitousness incomprehensible professionalism exhilaration indefatigable manifestation disentanglement"
words_string = string_shortWords

start_button_rect = pygame.Rect(WIDTH // 2 - 120, HEIGHT // 2, 240, 50)
quit_button_rect = pygame.Rect(WIDTH // 2 - 120, HEIGHT // 2 + 70, 240, 50)
restart_button_rect = pygame.Rect(WIDTH // 2 - 120, HEIGHT // 2 + 70, 240, 50)
home_button_rect = pygame.Rect(WIDTH // 2 - 120, HEIGHT // 2 + 140, 240, 50)

def initialize_game():
    global words, word_speed, score, typed_letters, last_spawn_time, game_over, current_level, level_up_score, word_delay, words_string, string_shortWords
    words = []
    word_speed = 1
    word_delay = 3000
    words_string = string_shortWords
    score = 0
    typed_letters = ""
    last_spawn_time = pygame.time.get_ticks()
    game_over = False
    current_level = 1

def draw_text(text, x, y, button_rect=None, color=WHITE):
    if button_rect is not None:
        center_x = button_rect.x + button_rect.width // 2
        center_y = button_rect.y + button_rect.height // 2
        text_width, text_height = font.size(text)
        text_x = center_x - text_width // 2
        text_y = center_y - text_height // 2
    else:
        text_x, text_y = x, y

    surface = font.render(text, True, color)
    screen.blit(surface, (text_x, text_y))

def draw_home_screen():
    title_text = big_font.render("Word Hunter", True, WHITE)
    under_text = small_font.render("CST8279 Technical Portfolio & Report - Christian Neeson", True, WHITE)

    screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 4 - title_text.get_height() // 2))
    screen.blit(under_text, (WIDTH // 2 - title_text.get_width() // 1.65, HEIGHT // 4 + title_text.get_height() // 1))

    pygame.draw.rect(screen, button_color, start_button_rect)
    if start_button_rect.collidepoint(pygame.mouse.get_pos()):
        pygame.draw.rect(screen, button_hover_color, start_button_rect)
    draw_text("Start Game", start_button_rect.x, start_button_rect.y, start_button_rect)

    pygame.draw.rect(screen, button_color, quit_button_rect)
    if quit_button_rect.collidepoint(pygame.mouse.get_pos()):
        pygame.draw.rect(screen, button_hover_color, quit_button_rect)
    draw_text("Quit Game", quit_button_rect.x, quit_button_rect.y, quit_button_rect)

def draw_game_over():
    game_over_text = font.render("Game Over", True, WHITE)
    game_over_score = font.render("Score: " + str(score), True, WHITE)

    screen.blit(game_over_text, (WIDTH // 2 - game_over_text.get_width() // 2, HEIGHT // 4 - game_over_text.get_height() // 2))
    screen.blit(game_over_score, (WIDTH // 2 - game_over_score.get_width() // 2, HEIGHT // 3 - game_over_score.get_height() // 2))

    pygame.draw.rect(screen, button_color, restart_button_rect)
    if restart_button_rect.collidepoint(pygame.mouse.get_pos()):
        pygame.draw.rect(screen, button_hover_color, restart_button_rect)
    draw_text("Restart", restart_button_rect.x, restart_button_rect.y, restart_button_rect)

    pygame.draw.rect(screen, button_color, home_button_rect)
    if home_button_rect.collidepoint(pygame.mouse.get_pos()):
        pygame.draw.rect(screen, button_hover_color, home_button_rect)
    draw_text("Go to Home", home_button_rect.x, home_button_rect.y, home_button_rect)


def grab_random_words(words_string, num_words=2):
    words_list = words_string.split()  # Assuming words are separated by whitespace
    if len(words_list) < num_words:
        raise ValueError("Not enough words in the input string.")

    selected_words = random.sample(words_list, num_words)
    return [{'text': word, 'x': 0, 'y': 0} for word in selected_words]

def spawn_word():
    selected_words = grab_random_words(words_string, num_words=2)
    print(selected_words)
    word = {
        'text': random.choice(selected_words)['text'],  # Use 'text' key
        'x': WIDTH,
        'y': random.randint(FONT_SIZE, HEIGHT - FONT_SIZE),
    }
    words.append(word)

def display_countdown(current_level):
    countdown_duration = 5  # in seconds
    countdown_start_time = time.time()

    while time.time() - countdown_start_time <= countdown_duration:
        # Clear the screen
        screen.blit(background_image, (0, 0))

        # Display the countdown text with level number
        countdown_text = f"Level {current_level} starting in {countdown_duration - int(time.time() - countdown_start_time)}"
        countdown_font = pygame.font.Font(None, FONT_SIZE)
        countdown_surface = countdown_font.render(countdown_text, True, WHITE)
        countdown_rect = countdown_surface.get_rect(center=(WIDTH // 2, HEIGHT // 2))
        screen.blit(countdown_surface, countdown_rect.topleft)

        pygame.display.flip()
        clock.tick(FPS)

    # Reset the screen
    screen.blit(background_image, (0, 0))
    pygame.display.flip()

def handle_events():
    global in_home_screen, game_over, words, score, typed_letters, last_spawn_time, current_level, level_up_score, word_speed

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if in_home_screen:
            if event.type == pygame.MOUSEBUTTONDOWN:
                if start_button_rect.collidepoint(pygame.mouse.get_pos()):
                    if game_over:
                        # Restart the game when clicking "Start Game" on the home screen during game over
                        initialize_game()
                        game_over = False
                    else:
                        in_home_screen = False
                elif quit_button_rect.collidepoint(pygame.mouse.get_pos()):
                    pygame.quit()
                    sys.exit()

        else:
            if event.type == pygame.KEYDOWN:
                if event.unicode.isalpha():
                    typed_letters += event.unicode
                elif event.key == pygame.K_BACKSPACE:
                    typed_letters = typed_letters[:-1]

            if event.type == pygame.MOUSEBUTTONDOWN:
                if game_over:
                    if restart_button_rect.collidepoint(pygame.mouse.get_pos()):
                        game_over = False
                        initialize_game()
                    elif home_button_rect.collidepoint(pygame.mouse.get_pos()):
                        in_home_screen = True

def update_game_state():
    global words, word_speed, score, typed_letters, game_over, current_level, level_up_score, last_spawn_time, word_delay, level_delay_countdown, string_shortWords, string_LongWords, string_LongerWords, words_string, image_display_start_time

    current_time = pygame.time.get_ticks()

    if in_home_screen:
        screen.blit(background_image, (0, 0))
        draw_home_screen()
    elif not game_over:
        screen.blit(background_image, (0, 0))

        if level_delay_countdown > 0:
            level_delay_countdown -= 1
            delay_text = f"Level {current_level} starting in: {level_delay_countdown // 1000 + 1}"
            draw_text(delay_text, WIDTH // 2 - FONT_SIZE * 2, HEIGHT // 2)

            if level_delay_countdown == 0:
                # Reset some variables and start the new level
                level_delay_countdown = 5000  # Set the delay for the next level
                current_level += 1
                word_delay = 3000
                word_speed += 1
                words_string = string_LongWords
            return
        elif current_time - last_spawn_time > word_delay:
            spawn_word()
            last_spawn_time = current_time

        for word in words[:]:
            word['x'] -= word_speed

            # Calculate word background rect with a 3px margin
            text_surface = font.render(str(word['text']), True, (0, 0, 0))  # Convert to string
            word_rect = text_surface.get_rect()
            word_background_rect = word_rect.inflate(6, 6)  # 3px margin on each side
            word_background_rect.move_ip(word['x'] - 3, word['y'] - 3)

            pygame.draw.rect(screen, (255, 255, 255), word_background_rect)

            # Draw word text within the background rect
            text_rect = text_surface.get_rect(center=word_background_rect.center)
            screen.blit(text_surface, text_rect.topleft)

            if word['x'] < 0:
                game_over = True

            if typed_letters == word['text'][:len(typed_letters)]:
                if typed_letters == word['text']:
                    # Center the image on the word's background rect
                    image_display_start_time = current_time
                    image_display_rect.center = word_background_rect.center

                    words.remove(word)
                    score += 1
                    typed_letters = ''

                    # switch for levels
                    if score == 5: # level 2
                        display_countdown(current_level+1)
                        current_level += 1
                        word_delay = 2000
                    elif score == 15: # level 3
                        display_countdown(current_level+1)
                        current_level += 1
                        word_speed = 1
                        word_delay = 3000
                        words_string = string_LongWords
                    elif score == 25: # level 4
                        display_countdown(current_level+1)
                        current_level += 1
                        word_delay = 3000
                        word_speed = 1.5
                        words_string = string_LongWords
                    elif score == 35: # level 5
                        display_countdown(current_level+1)
                        current_level += 1
                        word_delay = 2000
                        words_string = string_LongWords
                    elif score == 45: # level 6
                        display_countdown(current_level+1)
                        current_level += 1
                        word_delay = 1500
                        word_speed = 1.5
                        words_string = string_shortWords
                    elif score == 55: # level 7
                        display_countdown(current_level+1)
                        current_level += 1
                        word_delay = 2200
                        word_speed = 1.5
                        words_string = string_LongWords
                    elif score == 65: # level 8
                        display_countdown(current_level+1)
                        current_level += 1
                        word_delay = 3000
                        word_speed = 1
                        words_string = string_LongerWords
                    elif score == 75: # level 9
                        display_countdown(current_level+1)
                        current_level += 1
                        word_delay = 500
                        word_speed = 1
                        words_string = string_shortWords
                    elif score == 85: # level 10
                        display_countdown(current_level+1)
                        current_level += 1
                        word_delay = 1500
                        word_speed = 1.5
                        words_string = string_LongerWords

        typed_text = f"Typed: {typed_letters}"
        draw_text(typed_text, 10, HEIGHT - 50)

        score_text = f"Score: {score} | Level: {current_level}"
        draw_text(score_text, 10, 10)

        # Display the image for a specific duration
        if current_time - image_display_start_time < image_display_time:
            screen.blit(image_surface, image_display_rect.topleft)

    else:
        screen.blit(background_image, (0, 0))
        draw_game_over()

# Main game loop
while True:
    handle_events()
    update_game_state()
    pygame.display.flip()
    clock.tick(FPS)